# tipCalculator
iOS App Tip Calculator created with XCode,Swift

<p align="center">
  <img width="369" height="716" src="prework.gif">
</p>
